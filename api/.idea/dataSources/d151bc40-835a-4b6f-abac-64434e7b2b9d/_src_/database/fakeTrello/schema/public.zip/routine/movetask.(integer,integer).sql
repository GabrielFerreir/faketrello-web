create function movetask(pidtask integer, pidblock integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask) AND EXISTS(SELECT *
                                                FROM tb_blocks
                                                WHERE id_blocks = pIdBlock)
  THEN
    UPDATE tb_tasks SET id_block = pIdBlock WHERE id_task = pIdTask;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
