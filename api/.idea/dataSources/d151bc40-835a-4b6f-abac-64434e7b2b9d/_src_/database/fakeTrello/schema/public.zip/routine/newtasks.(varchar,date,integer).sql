create function newtasks(nametask character varying, date date, idblock integer) returns TABLE(idtask integer, nametaskr character varying, dater date, idblockowner integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask     INTEGER;
  vNameTask   VARCHAR(20);
  vDate       DATE;
  vBlockOwner INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = idblock)
  THEN
    INSERT INTO tb_tasks (name_task, final_date, id_block) VALUES (nametask, to_date(date, 'DD/MM/YYYY'), idblock)
    RETURNING id_block, name_task, to_char(final_date, 'DD/MM/YYYY'), id_block
      INTO vIdTask, vNameTask, vDate, vBlockOwner;
    RETURN QUERY
    SELECT
      vIdTask,
      vNameTask,
      vDate,
      vBlockOwner;
  END IF;
END;
$$;
