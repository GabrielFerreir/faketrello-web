create function newuser(emaild character varying, passw character varying, img character varying, namep character varying, usern character varying) returns TABLE(idnewuser integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdNewUser INTEGER;
BEGIN
  IF NOT exists(SELECT *
                FROM tb_login
                WHERE emailD = tb_login.email OR usern = tb_login.username)
  THEN
    INSERT INTO tb_login (email, password, profile_img, name, username) VALUES ($1, $2, $3, $4, $5)
    RETURNING id_user
      INTO vIdNewUser;
    RETURN QUERY
    SELECT vIdNewUser;
  ELSE
    RETURN QUERY 
    SELECT 0;
  END IF;
END
$$;
