create function deletecomment(pidcomment integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_comments
            WHERE id_comment = pIdComment)
  THEN
    DELETE FROM tb_comments WHERE id_comment = pIdComment;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
