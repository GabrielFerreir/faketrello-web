create function getpathimg(pidproject integer) returns TABLE(path character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT img_project
  FROM tb_projects
  WHERE id_project = pIdProject;
END;
$$;
