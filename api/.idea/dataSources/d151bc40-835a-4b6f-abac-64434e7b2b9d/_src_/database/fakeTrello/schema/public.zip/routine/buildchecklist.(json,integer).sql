create function buildchecklist(pchecklist json, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdBlock     INTEGER;
  vIdProject   INTEGER;
  vIdChecklist INTEGER;
BEGIN
  IF (SELECT "namechecklist"
      FROM json_to_recordset(pChecklist)
        AS x(
           "namechecklist" VARCHAR(100),
           "idTask" INTEGER,
           checked BOOLEAN
           )) IS NOT NULL
  THEN

    INSERT INTO tb_checklist_tasks (name_checklist, id_task, checked)
      SELECT
        "namechecklist",
        "idTask",
        checked
      FROM json_to_recordset(pChecklist)
        AS x(
           "namechecklist" VARCHAR(100),
           "idTask" INTEGER,
           checked BOOLEAN
           )
    RETURNING id_checklist
      INTO vIdChecklist;

  END IF;

  SELECT id_block
  INTO vIdBlock
  FROM tb_tasks
  WHERE id_task = (SELECT "idTask"
                   FROM json_to_recordset(pChecklist)
                     AS x(
                        "namechecklist" VARCHAR(100),
                        "idTask" INTEGER,
                        checked BOOLEAN
                        ));

  SELECT project_owner
  INTO vIdProject
  FROM tb_blocks
  WHERE id_blocks = vIdBlock;

  INSERT INTO tb_notifications (id_task, id_checklist, type, old_name, id_user, id_block, id_project, target_type)
  VALUES ((SELECT "idTask"
           FROM json_to_recordset(pChecklist)
             AS x(
                "namechecklist" VARCHAR(100),
                "idTask" INTEGER,
                checked BOOLEAN
                )),
          vIdChecklist,
          1,
          (SELECT "namechecklist"
           FROM json_to_recordset(pChecklist)
             AS x(
                "namechecklist" VARCHAR(100),
                "idTask" INTEGER,
                checked BOOLEAN
                )),
          pIdUser,
          (SELECT id_block
           FROM tb_tasks
           WHERE id_task = (SELECT "idTask"
                            FROM json_to_recordset(pChecklist)
                              AS x(
                                 "namechecklist" VARCHAR(100),
                                 "idTask" INTEGER,
                                 checked BOOLEAN
                                 ))),
          (SELECT project_owner
           FROM tb_blocks
           WHERE id_blocks = (SELECT id_block
                              FROM tb_tasks
                              WHERE id_task = (SELECT "idTask"
                                               FROM json_to_recordset(pChecklist)
                                                 AS x(
                                                    "namechecklist" VARCHAR(100),
                                                    "idTask" INTEGER,
                                                    checked BOOLEAN
                                                    )))),
          4);

  RETURN TRUE;
END;
$$;
