create function deleteuser(usern character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT
              username,
              email
            FROM tb_login
            WHERE username ILIKE $1 OR email ILIKE $1)
  THEN
    DELETE FROM tb_login WHERE username ILIKE $1 OR email ILIKE $1;
    RETURN TRUE ;
  END IF;
  RETURN FALSE ;
END
$$;
