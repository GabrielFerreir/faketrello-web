create function removeusersteam(idproj integer, idusert integer, permission boolean, iduseralvo integer) returns TABLE(statuscode integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vStatus INTEGER;
BEGIN
  IF permission <> FALSE
  THEN
    IF EXISTS(SELECT *
              FROM tb_team
              WHERE idproj = id_project AND id_user = idusert)
       AND EXISTS(SELECT *
                  FROM tb_team
                  WHERE idproj = id_project AND
                        iduseralvo = id_user)
    THEN
      DELETE FROM tb_team
      WHERE idproj = id_project AND
            id_user = iduseralvo
      RETURNING 200
        INTO
          vStatus;

      INSERT INTO tb_notifications (id_user, type, id_new_user, target_type)
      VALUES (idusert, 11, iduseralvo, 6);

      UPDATE tb_team SET notifications = TRUE WHERE id_project = idproj AND id_user <> idusert;

      RETURN QUERY
      SELECT vStatus;
    ELSE
      RETURN QUERY
      SELECT 404;
    END IF;
  ELSE
    RETURN QUERY
    SELECT 401;
  END IF;
END;
$$;
