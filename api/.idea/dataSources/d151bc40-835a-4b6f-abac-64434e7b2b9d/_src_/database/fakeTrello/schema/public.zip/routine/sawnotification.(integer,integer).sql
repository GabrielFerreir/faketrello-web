create function sawnotification(pidproject integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE tb_team
  SET notifications = FALSE
  WHERE id_project = pIdProject AND id_user = pIdUser;

  RETURN TRUE;
END;
$$;
