create function returndatauser(piduser integer) returns TABLE(username character varying, email character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT tl.username,tl.email FROM tb_login tl WHERE tl.id_user = pIdUser;
END;
$$;
