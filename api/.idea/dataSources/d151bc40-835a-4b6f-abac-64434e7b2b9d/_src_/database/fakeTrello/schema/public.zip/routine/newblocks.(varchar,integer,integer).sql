create function newblocks(nameq character varying, idproj integer, iduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdBlock INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = idproj)
  THEN
    INSERT INTO tb_blocks (name_blocks, project_owner) VALUES (nameq, idproj)
    RETURNING id_blocks
      INTO vIdBlock;

    INSERT INTO tb_notifications (id_block, id_user, id_project, new_name, type, target_type)
    VALUES (vIdBlock, idUser, idproj, nameq, 1, 1);

    UPDATE tb_team SET notifications = TRUE WHERE id_project = idproj AND id_user <> idUser;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
