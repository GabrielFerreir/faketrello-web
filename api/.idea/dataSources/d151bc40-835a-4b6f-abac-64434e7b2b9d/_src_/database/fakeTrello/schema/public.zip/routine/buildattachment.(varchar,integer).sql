create function buildattachment(path character varying, idtask integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = idtask)
  THEN
    UPDATE tb_tasks SET attachment = path WHERE id_task = idtask;
    RETURN TRUE ;
  END IF;
END;
$$;
