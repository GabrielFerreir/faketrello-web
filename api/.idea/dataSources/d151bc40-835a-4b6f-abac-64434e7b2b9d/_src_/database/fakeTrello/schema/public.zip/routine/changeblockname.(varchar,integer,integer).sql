create function changeblockname(pnewname character varying, pidblock integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  oldName VARCHAR(50);
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = pIdBlock)
  THEN
    SELECT name_blocks
    INTO oldName
    FROM tb_blocks
    WHERE id_blocks = pIdBlock;

    UPDATE tb_blocks
    SET name_blocks = pNewName
    WHERE id_blocks = pIdBlock;

    INSERT INTO tb_notifications(id_user, id_block, type, old_name, new_name,id_project)
    VALUES(pIdUser, pIdBlock, 2, oldName, (SELECT name_blocks FROM tb_blocks WHERE id_blocks = pIdBlock), (SELECT project_owner from tb_blocks WHERE id_blocks = pIdBlock));
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
