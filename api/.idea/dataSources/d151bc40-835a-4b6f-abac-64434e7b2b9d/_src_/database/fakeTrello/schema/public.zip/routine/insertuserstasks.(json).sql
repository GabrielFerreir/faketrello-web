create function insertuserstasks(users json) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO tb_team_tasks (id_task, id_user)
    SELECT
      idtask,
      iduser
    FROM json_to_recordset(users)
      AS x(
         idtask INTEGER,
         iduser INTEGER
         );
  RETURN TRUE;
END;
$$;
