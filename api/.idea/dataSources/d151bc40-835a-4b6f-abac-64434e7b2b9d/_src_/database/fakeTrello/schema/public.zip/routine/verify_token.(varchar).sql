create function verify_token(usern character varying) returns TABLE(usera character varying, status text)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT
              l.username,
              l.email
            FROM tb_login l
            WHERE l.username ILIKE $1 OR l.email ILIKE $1 AND "authEmail" = FALSE )
  THEN
    UPDATE tb_login l
    SET "authEmail" = TRUE
    WHERE l.username ILIKE $1 OR l.email ILIKE $1;
    RETURN QUERY
      SELECT
    $1,
    'Autenticado com sucesso' :: TEXT;
  END IF;
  IF EXISTS(SELECT
              l.username,
              l.email
            FROM tb_login l
            WHERE l.username ILIKE $1 OR l.email ILIKE $1 AND "authEmail" = TRUE)
  THEN
    RETURN QUERY
    SELECT
      $1,
      'Já autenticado' :: TEXT;
  END IF;
END
$$;
