create function newcomment(pidtask integer, pcomment text, piduser integer) returns TABLE(idcomment integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdComment INTEGER;
  vIdBlock   INTEGER;
  vIdProject INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    INSERT INTO tb_comments (id_task, comment)
    VALUES (pIdTask, pComment)
    RETURNING id_comment
      INTO vIdComment;

    SELECT
      tt.id_block,
      (SELECT project_owner
       FROM tb_blocks
       WHERE id_blocks = tt.id_block)
    INTO vIdBlock, vIdProject
    FROM tb_tasks tt
    WHERE id_task = pIdTask;

    INSERT INTO tb_notifications (id_comment, type, target_type, id_user, id_task, id_block, id_project)
    VALUES (vIdComment, 1, 3, pIdUser, pIdTask, vIdBlock, vIdProject);

    UPDATE tb_team
    SET notifications = TRUE
    WHERE id_project = vIdProject AND id_user <> pIdUser;

    RETURN QUERY
    SELECT vIdComment;
  END IF;
END;
$$;
