create function deleteproject(idproject integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = $1)
  THEN
    DELETE FROM tb_projects WHERE id_project = $1;
    RETURN TRUE ;
  END IF;
  RETURN FALSE ;
END;
$$;
