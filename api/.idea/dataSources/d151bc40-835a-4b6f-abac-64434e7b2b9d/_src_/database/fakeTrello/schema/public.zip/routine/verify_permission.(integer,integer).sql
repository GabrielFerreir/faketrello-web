create function verify_permission(idproj integer, iduser integer) returns TABLE(idproject integer, iduserr integer, permission boolean)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team
            WHERE idproj = id_project AND iduser = id_user)
  THEN
    RETURN QUERY
    SELECT
      id_project,
      id_user,
      permissions
    FROM tb_team
    WHERE idproj = id_project AND iduser = id_user;
  END IF;
END;
$$;
