create function changepass(usern character varying, oldpass character varying, newpass character varying, whocall boolean) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF whocall = TRUE
  THEN

    IF EXISTS(SELECT
                username,
                password
              FROM tb_login
              WHERE (username ILIKE $1 OR email ILIKE $1) AND password = $2)
    THEN
      UPDATE tb_login
      SET password = $3
      WHERE username ILIKE $1 OR email ILIKE $1;
      RETURN TRUE;
    END IF;
    RETURN FALSE ;
  ELSE
    IF EXISTS(SELECT
                username,
                password
              FROM tb_login
              WHERE username ILIKE $1 OR email ILIKE $1)
    THEN
      UPDATE tb_login
      SET password = $3
      WHERE username ILIKE $1 OR email ILIKE $1;
      RETURN TRUE;
    END IF;
    RETURN FALSE ;

  END IF;
END;
$$;
