create function removeimg(piduser integer) returns TABLE(path character varying)
LANGUAGE plpgsql
AS $$
DECLARE
  vPath VARCHAR(50);
BEGIN
  IF EXISTS(SELECT *
            FROM tb_login
            WHERE id_user = pIdUser AND profile_img <> '/imgsUser/default.png')
  THEN
    SELECT profile_img
    INTO vPath
    FROM tb_login
    WHERE id_user = pIdUser;

    UPDATE tb_login
    SET profile_img = '/imgsUser/default.png'
    WHERE id_user = pIdUser;

    RETURN QUERY
    SELECT vPath;
  END IF;
END;
$$;
