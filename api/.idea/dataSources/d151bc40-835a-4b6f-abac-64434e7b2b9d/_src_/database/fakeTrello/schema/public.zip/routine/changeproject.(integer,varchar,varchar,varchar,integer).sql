create function changeproject(idproj integer, namep character varying, descrip character varying, imgp character varying, idowner integer) returns TABLE(idprojectr integer)
LANGUAGE plpgsql
AS $$
DECLARE
  idproject INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = idproj AND id_user_owner = idowner)
  THEN
    UPDATE tb_projects
    SET
      name_project = namep,
      description  = descrip,
      img_project  = imgp
    WHERE id_project = idproj AND id_user_owner = idowner
    RETURNING id_project
      INTO idproject;
    RETURN QUERY 
      SELECT 
    idproject;
  END IF;
END;
$$;
