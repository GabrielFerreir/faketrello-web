create function exitproject(piduser integer, pidproject integer) returns TABLE(status integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vQntdAdmins  INTEGER;
  vQntdMembers INTEGER;
BEGIN

  IF EXISTS(SELECT *
            FROM tb_team
            WHERE id_user = pIdUser AND id_project = pIdProject AND permissions = FALSE)
  THEN
    DELETE FROM tb_team
    WHERE id_user = pIdUser AND id_project = pIdProject;

    INSERT INTO tb_notifications (id_user, type, target_type, id_project)
    VALUES (pIdUser, 8, 6, pIdProject);

    UPDATE tb_team SET notifications = TRUE WHERE id_project = pIdProject AND id_user <> pIdUser;

    RETURN QUERY
    SELECT 1;
  END IF;

  SELECT COUNT(id_user)
  OVER (
    PARTITION BY 1 )
  INTO vQntdAdmins
  FROM tb_team
  WHERE id_project = pIdProject
        AND permissions
  LIMIT 1;

  SELECT COUNT(id_user)
  OVER (
    PARTITION BY 1 )
  INTO vQntdMembers
  FROM tb_team
  WHERE id_project = pIdProject
        AND permissions = FALSE
  LIMIT 1;

  IF vQntdAdmins > 1
  THEN

    DELETE FROM tb_team
    WHERE id_user = pIdUser AND id_project = pIdProject;

    INSERT INTO tb_notifications (id_user, type, target_type, id_project)
    VALUES (pIdUser, 8, 6, pIdProject);

    RETURN QUERY
    SELECT 2;
  ELSEIF vQntdAdmins > 1 AND vQntdMembers > 0
    THEN
      RETURN QUERY
      SELECT 3;
  ELSEIF vQntdAdmins = 1 AND vQntdMembers = 0
    THEN
      EXECUTE deactivateProject(pIdProject, pIdUser);
      RETURN QUERY
      SELECT 4;
  END IF;
  RETURN QUERY
  SELECT 0;
END;
$$;
