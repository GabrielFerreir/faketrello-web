create function buildchecklist(pchecklist json) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE NOTICE '%', pChecklist;
  INSERT INTO tb_checklist_tasks (name_checklist, id_task, checked)
    SELECT
      "namechecklist",
      "idTask",
      checked
    FROM json_to_recordset(pChecklist)
      AS x(
         "namechecklist" VARCHAR(20),
         "idTask" INTEGER,
         checked BOOLEAN
         );
  RETURN TRUE;
END;
$$;
