create function newtasks(nametask character varying, date timestamp without time zone, descrip text, idblock integer) returns TABLE(idtask integer, nametaskr character varying, dater timestamp without time zone, description text, idblockowner integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask     INTEGER;
  vNameTask   VARCHAR(20);
  vDate       TIMESTAMP;
  vDescript   TEXT;
  vBlockOwner INTEGER;

BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = idblock)
  THEN
    INSERT INTO tb_tasks (name_task, final_date, description, id_block) VALUES (nametask, date, descrip, idblock)
    RETURNING id_task, name_task, final_date, description, id_block
      INTO vIdTask, vNameTask, vDate, vDescript, vBlockOwner;
    RETURN QUERY
    SELECT
      vIdTask,
      vNameTask,
      vDate,
      vDescript,
      vBlockOwner;
  END IF;
END;
$$;
