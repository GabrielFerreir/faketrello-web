create function newproject(nameproject character varying, iddono integer, descricao character varying, imgproject character varying) returns TABLE(idproject integer)
LANGUAGE plpgsql
AS $$
DECLARE
  idprojectR INTEGER;
BEGIN
  IF EXISTS(SELECT l.id_user
            FROM tb_login l
            WHERE l.id_user = idDono)
  THEN
    INSERT INTO tb_projects (name_project, id_user_owner, description, img_project) VALUES ($1, $2, $3, $4)
    RETURNING id_project
      INTO idprojectR;
    INSERT INTO tb_notifications(id_user, id_project, type) VALUES (idDono,idprojectR, 1);
    RETURN QUERY
    SELECT idprojectR;
  END IF;
END;
$$;
