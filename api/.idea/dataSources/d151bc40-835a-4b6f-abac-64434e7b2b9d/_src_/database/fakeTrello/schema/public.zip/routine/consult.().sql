create function consult() returns TABLE(email character varying, username character varying, password character varying, img character varying, name character varying, emailauth boolean)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    tb_login.email,
    tb_login.username,
    tb_login.password,
    tb_login.profile_img,
    tb_login.name,
    tb_login."authEmail"
  FROM tb_login;
END
$$;
