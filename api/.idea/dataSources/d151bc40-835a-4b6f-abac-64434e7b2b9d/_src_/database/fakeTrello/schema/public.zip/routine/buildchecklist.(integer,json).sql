create function buildchecklist(pidtask integer, pchecklist json) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    INSERT INTO tb_checklist_tasks (name_checklist, id_task, checked)
      SELECT
        "namechecklist",
        "idTask",
        checked
      FROM json_to_recordset(pChecklist)
        AS x(
           "namechecklist" VARCHAR(20),
           "idTask" INTEGER,
           checked BOOLEAN
           );
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
