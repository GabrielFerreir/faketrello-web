create function buildchecklist(idtask integer, checklist json) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = idTask)
  THEN
    INSERT INTO tb_checklist_tasks (name_checklist, id_task, checked)
      SELECT 
        namechecklist,
        idtask,
        checked
    from json_to_recordset(checklist)
    as x(
      namechecklist VARCHAR(20),
      idtask INTEGER,
      checked BOOLEAN
         );
    RETURN TRUE ;
  END IF;
  RETURN FALSE ;
END;
$$;
