create function insertmemberstask(pidtask integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
     AND NOT EXISTS(SELECT *
                    FROM tb_team_tasks
                    WHERE pIdTask = id_task AND pIdUser = id_user)
  THEN
    INSERT INTO tb_team_tasks (id_task, id_user) VALUES (pIdTask, pIdUser);
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
