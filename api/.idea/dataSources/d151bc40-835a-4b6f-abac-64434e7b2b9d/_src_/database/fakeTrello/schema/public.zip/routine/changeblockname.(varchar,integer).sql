create function changeblockname(pnewname character varying, pidblock integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = pIdBlock)
  THEN
    UPDATE tb_blocks
    SET name_blocks = pNewName
    WHERE id_blocks = pIdBlock;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
