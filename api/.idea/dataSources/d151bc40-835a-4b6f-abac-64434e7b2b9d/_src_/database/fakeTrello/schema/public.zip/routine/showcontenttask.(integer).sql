create function showcontenttask(pidtask integer) returns TABLE(nametask character varying, attachment character varying, finaldate timestamp without time zone, description text, team json, comments json, checklists json)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    RETURN QUERY
    SELECT
      l.name_task,
      l.attachment,
      l.final_date,
      l.description,
      (SELECT coalesce(json_agg(teamTask), '[]')
       FROM (SELECT id_user
             FROM tb_team_tasks
             WHERE id_task = pIdTask) AS teamTask),

      (SELECT coalesce(json_agg(jsonComments), '[]')
       FROM (SELECT
               l.id_comment,
               l.comment
             FROM tb_comments l
             WHERE l.id_task = pIdTask) AS jsonComments),

      (SELECT coalesce(json_agg(jsonChecklist), '[]')
       FROM (SELECT
               id_checklist,
               name_checklist,
               checked
             FROM tb_checklist_tasks
             WHERE id_task = pIdTask) AS jsonChecklist)
    FROM tb_tasks l
    WHERE l.id_task = pIdTask;

  END IF;
END;
$$;
