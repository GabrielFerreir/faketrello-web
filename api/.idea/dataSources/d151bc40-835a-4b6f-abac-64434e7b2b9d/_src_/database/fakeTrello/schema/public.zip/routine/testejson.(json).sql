create function testejson(userjson json) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO "tb_testeJson" (name, age, email)
    SELECT
      nameuser,
      ageuser,
      emailuser
    FROM json_to_recordset(userJson)
      AS x(
         nameuser VARCHAR(50),
         ageuser SMALLINT,
         emailuser VARCHAR(50)
         );
  RETURN TRUE ;
END;
$$;
