create function changeuser(pass character varying, usern character varying, usertoken character varying, emailp character varying, nomep character varying) returns TABLE(emaild character varying, namep character varying, usernamer character varying, imageuser character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF NOT EXISTS(SELECT
                  l.username,
                  l.email
                FROM tb_login l
                WHERE l.username = $2 OR l.email = $4
                EXCEPT (SELECT
                          l.username,
                          l.email
                        FROM tb_login l
                        WHERE l.username = $3 OR l.email = $3))
  THEN

    UPDATE tb_login l
    SET username = $2,
      email      = $4,
      name       = $5
    WHERE l.username = $3 OR l.email = $3;

    RETURN QUERY
    SELECT
      $4,
      $5,
      $2,
      tb_login.profile_img
    FROM tb_login;
  END IF;
END
$$;
