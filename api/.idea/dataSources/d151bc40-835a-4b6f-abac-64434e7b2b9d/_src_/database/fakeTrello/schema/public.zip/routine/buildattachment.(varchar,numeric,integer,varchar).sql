create function buildattachment(pfilename character varying, psize numeric, pidtask integer, ppath character varying) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdAttachment INTEGER;
  vIdBlock      INTEGER;
  vIdProject    INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    INSERT INTO tb_attachment (file_name, size, id_task, path)
    VALUES (pFileName, pSize, pIdTask, pPath)
    RETURNING id_attachment
      INTO vIdAttachment;

    SELECT
      id_block,
      (SELECT project_owner
       FROM tb_blocks
       WHERE id_blocks = vIdBlock)
    INTO vIdBlock,vIdProject
    FROM tb_tasks
    WHERE id_task = pIdTask;

    INSERT INTO tb_notifications (id_attachment, type, target_type, old_name,id_block,id_project,id_task)
    VALUES (vIdAttachment, 1, 5, pFileName,vIdBlock,vIdProject,pIdTask);

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
