create function buildattachment(pfilename character varying, psize integer, pidtask integer, ppath character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    INSERT INTO tb_attachment(file_name, size, id_task, path) VALUES (pFileName, pSize, pIdTask, pPath);
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
