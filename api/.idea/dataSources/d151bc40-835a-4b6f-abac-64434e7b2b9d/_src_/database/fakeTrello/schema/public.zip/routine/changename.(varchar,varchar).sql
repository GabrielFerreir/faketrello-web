create function changename(pnewname character varying, pusername character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN

  UPDATE tb_login
  SET name = pNewName
  WHERE username = pUsername;
  RETURN TRUE;
  
END
$$;
