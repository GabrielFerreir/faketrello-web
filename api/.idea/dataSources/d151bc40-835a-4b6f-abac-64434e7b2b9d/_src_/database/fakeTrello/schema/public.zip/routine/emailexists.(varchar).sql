create function emailexists(emailuser character varying) returns TABLE(usern character varying, emailu character varying, passw character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT l.email
            FROM tb_login l
            WHERE l.email ILIKE $1)
  THEN
    RETURN QUERY
    SELECT
      l.username,
      l.email,
      l.password
    FROM tb_login l
    WHERE l.email ILIKE $1;
  END IF;
END;
$$;
