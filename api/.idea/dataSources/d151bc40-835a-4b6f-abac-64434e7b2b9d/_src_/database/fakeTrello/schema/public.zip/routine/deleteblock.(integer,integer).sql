create function deleteblock(pidblock integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = pIdBlock)
  THEN
    DELETE FROM tb_tasks
    WHERE id_block = pIdBlock;

    INSERT INTO tb_notifications (id_project, type, id_user, old_name)
    VALUES ((SELECT project_owner
             FROM tb_blocks
             WHERE id_blocks = pIdBlock), 3, pIdUser, (SELECT name_blocks
                                                       FROM tb_blocks
                                                       WHERE id_blocks = pIdBlock));
    
    DELETE FROM tb_notifications WHERE id_block = pIdBlock;

    DELETE FROM tb_blocks
    WHERE id_blocks = pIdBlock;
    RETURN TRUE;

  END IF;
  RETURN FALSE;
END;
$$;
