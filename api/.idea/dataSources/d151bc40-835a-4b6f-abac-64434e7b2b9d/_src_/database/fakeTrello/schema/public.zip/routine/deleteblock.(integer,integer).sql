create function deleteblock(pidblock integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTasks INTEGER [];
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = pIdBlock)
  THEN

    vIdTasks := ARRAY (SELECT id_task FROM tb_tasks WHERE id_block = pIdBlock);
    
    DELETE FROM tb_attachment WHERE id_task = ANY (vIdTasks);
    DELETE FROM tb_comments WHERE id_task = ANY (vIdTasks);
    DELETE FROM tb_checklist_tasks WHERE id_task = ANY (vIdTasks);
    DELETE FROM tb_team_tasks WHERE id_task = ANY (vIdTasks);
    
    DELETE FROM tb_notifications WHERE id_block = pIdBlock;

    DELETE FROM tb_tasks
    WHERE id_block = pIdBlock;

    INSERT INTO tb_notifications (id_project, type, id_user, old_name, target_type)
    VALUES ((SELECT project_owner
             FROM tb_blocks
             WHERE id_blocks = pIdBlock), 3, pIdUser, (SELECT name_blocks
                                                       FROM tb_blocks
                                                       WHERE id_blocks = pIdBlock), 1);

    UPDATE tb_team
    SET notifications = TRUE
    WHERE id_project = (SELECT project_owner
                        FROM tb_blocks
                        WHERE id_blocks = pIdBlock) AND id_user <> pIdUser;

    DELETE FROM tb_notifications
    WHERE id_block = pIdBlock;

    DELETE FROM tb_blocks
    WHERE id_blocks = pIdBlock;
    RETURN TRUE;

  END IF;
  RETURN FALSE;
END;
$$;
