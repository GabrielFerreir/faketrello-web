create function insertowner(pidproject integer, piduser integer, permission boolean) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = pIdProject)
  THEN
    INSERT
    INTO tb_team (id_project, id_user, permissions) VALUES (pIdProject, pIdUser, permission);
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
