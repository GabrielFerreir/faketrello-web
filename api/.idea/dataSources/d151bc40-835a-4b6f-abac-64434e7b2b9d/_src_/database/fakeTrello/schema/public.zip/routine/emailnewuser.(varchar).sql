create function emailnewuser(pemail character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT email
            FROM tb_login
            WHERE email ILIKE pEmail)
  THEN
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
