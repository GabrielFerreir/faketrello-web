create function insertmemberstask(pidtask integer, piduser integer, pidolduser integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
     AND NOT EXISTS(SELECT *
                    FROM tb_team_tasks
                    WHERE pIdTask = id_task AND pIdUser = id_user)
  THEN
    INSERT INTO tb_team_tasks (id_task, id_user) VALUES (pIdTask, pIdUser);

    INSERT INTO tb_notifications (id_task, id_block, id_project, type, target_type, id_user, id_new_user)
    VALUES (pIdTask,
            (SELECT id_block
             FROM tb_tasks
             WHERE id_task = pIdTask),
            (SELECT project_owner
             FROM tb_blocks
             WHERE id_blocks = (SELECT id_block
                                FROM tb_tasks
                                WHERE id_task = pIdTask)), 7, 2, pIdOldUser, pIdUser);

    UPDATE tb_team
    SET notifications = TRUE
    WHERE id_project = (SELECT project_owner
                        FROM tb_blocks
                        WHERE id_blocks = (SELECT id_block
                                           FROM tb_tasks
                                           WHERE id_task = pIdTask)) AND id_user <> pIdOldUser;

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
