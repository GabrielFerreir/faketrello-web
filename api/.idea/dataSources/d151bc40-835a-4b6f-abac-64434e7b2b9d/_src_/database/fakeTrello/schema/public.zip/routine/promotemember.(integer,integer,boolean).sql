create function promotemember(pidproject integer, pidusertarget integer, permission boolean) returns TABLE(status integer)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team
            WHERE id_project = pIdProject AND
                  id_user = pIdUserTarget AND
                  permissions = FALSE) AND permission = TRUE
  THEN

    UPDATE tb_team
    SET permissions = TRUE
    WHERE id_project = pIdProject AND
          id_user = pIdUserTarget AND
          permissions = FALSE;
    RETURN QUERY
    SELECT 1;
  END IF;
  IF EXISTS(SELECT *
            FROM tb_team
            WHERE id_project = pIdProject AND
                  id_user = pIdUserTarget AND
                  permissions = TRUE) AND permission = TRUE
  THEN

    UPDATE tb_team
    SET permissions = FALSE
    WHERE id_project = pIdProject AND
          id_user = pIdUserTarget AND
          permissions = TRUE;
    RETURN QUERY
    SELECT 2;
  END IF;
  RETURN QUERY
  SELECT 0;
END;
$$;
