create function changeproject(idproj integer, namep character varying, descrip character varying, imgp character varying, permission boolean, iduser integer) returns TABLE(idprojectr integer)
LANGUAGE plpgsql
AS $$
DECLARE
  idproject INTEGER;
  vOldName  VARCHAR(100);
BEGIN
  IF permission <> FALSE AND
     EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = idproj)
  THEN

    SELECT name_project
    INTO vOldName
    FROM tb_projects
    WHERE id_project = idproj;

    UPDATE tb_projects
    SET
      name_project = namep,
      description  = descrip,
      img_project  = imgp,
      active       = TRUE
    WHERE id_project = idproj
    RETURNING id_project
      INTO idproject;

    IF ((SELECT name_project
         FROM tb_projects
         WHERE id_project = idproj) <> vOldName)
    THEN

      INSERT INTO tb_notifications (id_user, type, target_type, id_project, old_name, new_name)
      VALUES (idUser, 2, 6, idproj, vOldName, (SELECT name_project
                                               FROM tb_projects
                                               WHERE id_project = idproj));

      UPDATE tb_team SET notifications = TRUE WHERE id_project = idproj AND id_user <> idUser;
    ELSE
      INSERT INTO tb_notifications (id_user, type, target_type, id_project)
      VALUES (idUser, 2, 6, idproj);
      
      UPDATE tb_team SET notifications = TRUE WHERE id_project = idproj AND id_user <> idUser;

    END IF;

    RETURN QUERY
    SELECT idproject;
  END IF;
END;
$$;
