create function timeproject(teamjson json) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO tb_time (id_project, id_user, permissions)
    SELECT
      idproject,
      iduser,
      permission
    FROM json_to_recordset(teamJson)
      AS x(
         idproject INTEGER,
         iduser INTEGER,
         permission SMALLINT
         );
  RETURN TRUE ;
END;
$$;
