create function removemembertask(pidrelation integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team_tasks
            WHERE pIdRelation = id_team_task)
  THEN
    DELETE FROM tb_team_tasks
    WHERE pIdRelation = id_team_task;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
