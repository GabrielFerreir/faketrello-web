create function exitteamtask(pidrelation integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask        INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team_tasks
            WHERE pIdRelation = id_team_task)
  THEN

    SELECT
      id_task
    INTO vIdTask
    FROM tb_team_tasks
    WHERE id_team_task = pIdRelation;

    DELETE FROM tb_team_tasks
    WHERE pIdRelation = id_team_task;

    INSERT INTO tb_notifications (id_task, id_block, id_project, type, target_type, id_user)
    VALUES (vIdTask,
            (SELECT id_block
             FROM tb_tasks
             WHERE id_task = vIdTask),
            (SELECT project_owner
             FROM tb_blocks
             WHERE id_blocks = (SELECT id_block
                                FROM tb_tasks
                                WHERE id_task = vIdTask)),
            8,
            2,
            pIdUser);

    UPDATE tb_team
    SET notifications = TRUE
    WHERE id_project = (SELECT project_owner
                        FROM tb_blocks
                        WHERE id_blocks = (SELECT id_block
                                           FROM tb_tasks
                                           WHERE id_task = vIdTask)) AND id_user <> pIdUser;

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
