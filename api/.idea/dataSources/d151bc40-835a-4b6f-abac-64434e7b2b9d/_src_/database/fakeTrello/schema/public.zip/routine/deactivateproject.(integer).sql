create function deactivateproject(idproject integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = $1 AND active = TRUE)
  THEN
    UPDATE tb_projects
    SET active = FALSE
    WHERE id_project = $1;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
