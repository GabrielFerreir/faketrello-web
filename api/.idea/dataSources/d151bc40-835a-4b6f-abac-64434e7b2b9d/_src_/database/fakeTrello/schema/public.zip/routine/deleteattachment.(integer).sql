create function deleteattachment(pidattachment integer) returns TABLE(path character varying)
LANGUAGE plpgsql
AS $$
DECLARE
  vPath VARCHAR(50);
BEGIN
  IF EXISTS(SELECT *
            FROM tb_attachment
            WHERE id_attachment = pIdAttachment)
  THEN
    SELECT l.path
    INTO vPath
    FROM tb_attachment l
    WHERE id_attachment = pIdAttachment;

    DELETE FROM tb_attachment
    WHERE id_attachment = pIdAttachment;
    RETURN QUERY
    SELECT vPath;
  END IF;
END;
$$;
