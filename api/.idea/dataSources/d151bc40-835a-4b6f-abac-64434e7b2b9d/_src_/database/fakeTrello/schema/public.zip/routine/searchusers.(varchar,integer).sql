create function searchusers(puser character varying, idproject integer) returns TABLE(iduser integer, nameuser character varying, username character varying, imguser character varying, permissions boolean)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdUser INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_login
            WHERE tb_login.username ILIKE pUser OR tb_login.email ILIKE pUser OR tb_login.name ILIKE pUser)
  THEN
    SELECT id_user
    INTO vIdUser
    FROM tb_login
    WHERE tb_login.username ILIKE pUser OR email ILIKE pUser OR name ILIKE pUser;

    IF EXISTS(SELECT *
              FROM tb_team
              WHERE tb_team.id_user = vIdUser AND id_project = idProject)
    THEN
      RETURN QUERY
      SELECT
        tb_login.id_user,
        name,
        tb_login.username,
        profile_img,
        tb_team.permissions
      FROM tb_login
        INNER JOIN tb_team ON tb_login.id_user = tb_team.id_user
      WHERE tb_login.id_user = vIdUser AND id_project = idProject;
    ELSE RETURN QUERY
    SELECT
      tb_login.id_user,
      name,
      tb_login.username,
      profile_img,
     null :: BOOLEAN
    FROM tb_login
    WHERE tb_login.id_user = vIdUser;
    END IF;
  END IF;
END;
$$;
