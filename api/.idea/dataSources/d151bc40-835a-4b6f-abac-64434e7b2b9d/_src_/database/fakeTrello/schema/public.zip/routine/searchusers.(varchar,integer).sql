create function searchusers(puser character varying, idproject integer) returns TABLE(iduser integer, nameuser character varying, username character varying, imguser character varying)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdUser INTEGER [];
  reg     tb_team%ROWTYPE;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_login
            WHERE tb_login.username ILIKE '%' || pUser || '%' OR
                  tb_login.email ILIKE '%' || pUser || '%' OR
                  tb_login.name ILIKE '%' || pUser || '%')
  THEN
    vIdUser :=  ARRAY(SELECT id_user
                      FROM tb_login
                      WHERE tb_login.username ILIKE '%' || pUser || '%' OR
                            email ILIKE '%' || pUser || '%' OR
                            name ILIKE '%' || pUser || '%');

    FOR reg IN
    SELECT id_user
    FROM tb_team
    WHERE id_user = ANY (vIdUser)
    LOOP
      vIdUser = array_remove(vIdUser, (SELECT id_user
                                       FROM tb_team
                                       WHERE id_user = ANY (vIdUser) AND id_project = idproject LIMIT 1));
    END LOOP;

    RETURN QUERY
    SELECT
      tb_login.id_user,
      name,
      tb_login.username,
      profile_img
    FROM tb_login
    WHERE tb_login.id_user = ANY (vIdUser) LIMIT 10;
  END IF;
END;
$$;
