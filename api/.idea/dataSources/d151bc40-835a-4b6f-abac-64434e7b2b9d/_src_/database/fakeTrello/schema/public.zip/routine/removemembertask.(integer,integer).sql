create function removemembertask(pidrelation integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask        INTEGER;
  vIdUserRemoved INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team_tasks
            WHERE pIdRelation = id_team_task)
  THEN

    SELECT
      id_task,
      id_user
    INTO vIdTask, vIdUserRemoved
    FROM tb_team_tasks
    WHERE id_team_task = pIdRelation;

    DELETE FROM tb_team_tasks
    WHERE pIdRelation = id_team_task;

    INSERT INTO tb_notifications (id_task, id_block, id_project, type, target_type, id_user, id_new_user)
    VALUES (vIdTask,
            (SELECT id_block
             FROM tb_tasks
             WHERE id_task = vIdTask),
            (SELECT project_owner
             FROM tb_blocks
             WHERE id_blocks = (SELECT id_block
                                FROM tb_tasks
                                WHERE id_task = vIdTask)),
            7,
            2,
            pIdUser,
            vIdUserRemoved);

    UPDATE tb_team
    SET notifications = TRUE
    WHERE id_project = (SELECT project_owner
                        FROM tb_blocks
                        WHERE id_blocks = (SELECT id_block
                                           FROM tb_tasks
                                           WHERE id_task = vIdTask)) AND id_user <> pIdUser;

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
