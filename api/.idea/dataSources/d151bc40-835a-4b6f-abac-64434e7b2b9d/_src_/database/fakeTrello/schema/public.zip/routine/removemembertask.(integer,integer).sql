create function removemembertask(pidtask integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team_tasks
            WHERE pIdTask = id_task AND pIdUser = id_user)
  THEN
    DELETE FROM tb_team_tasks
    WHERE pIdTask = id_task AND pIdUser = id_user;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
