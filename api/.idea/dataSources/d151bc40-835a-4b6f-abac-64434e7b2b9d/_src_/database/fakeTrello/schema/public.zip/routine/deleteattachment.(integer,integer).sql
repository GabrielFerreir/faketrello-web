create function deleteattachment(pidattachment integer, piduser integer) returns TABLE(path character varying)
LANGUAGE plpgsql
AS $$
DECLARE
  vPath    VARCHAR(50);
  vOldName VARCHAR(100);
BEGIN
  IF EXISTS(SELECT *
            FROM tb_attachment
            WHERE id_attachment = pIdAttachment)
  THEN
    SELECT
      l.path,
      file_name
    INTO vPath, vOldName
    FROM tb_attachment l
    WHERE id_attachment = pIdAttachment;

    DELETE FROM tb_attachment
    WHERE id_attachment = pIdAttachment;

    INSERT INTO tb_notifications (id_task, target_type, id_user, old_name, type, id_block, id_project)
    VALUES ((SELECT id_task
             FROM tb_attachment
             WHERE id_attachment = pIdAttachment),
            5,
            pIdUser,
            vOldName,
            3,
            (SELECT id_block
             FROM tb_tasks
             WHERE id_task = (SELECT id_task
                              FROM tb_attachment
                              WHERE id_attachment = pIdAttachment)),
            (SELECT project_owner
             FROM tb_blocks
             WHERE id_block = (SELECT id_block
                               FROM tb_tasks
                               WHERE id_task = (SELECT id_task
                                                FROM tb_attachment
                                                WHERE id_attachment = pIdAttachment))));

    RETURN QUERY
    SELECT vPath;
  END IF;
END;
$$;
