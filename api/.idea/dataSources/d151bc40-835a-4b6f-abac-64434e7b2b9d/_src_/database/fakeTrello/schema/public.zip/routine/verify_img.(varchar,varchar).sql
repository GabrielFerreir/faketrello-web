create function verify_img(img character varying, usern character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT
              profile_img,
              username,
              email
            FROM tb_login l
            WHERE l.email = usern OR l.username = usern)
  THEN
    UPDATE tb_login l
    SET profile_img = $1
    WHERE l.email = usern OR l.username = usern;
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
END;
$$;
