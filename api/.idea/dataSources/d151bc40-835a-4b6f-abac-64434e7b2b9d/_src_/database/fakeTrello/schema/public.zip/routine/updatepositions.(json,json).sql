create function updatepositions(ppositions json, poldpositions json) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTarefa INTEGER;
  vIndex    INTEGER := 0;
BEGIN

  FOR vIdTarefa IN SELECT *
                   FROM json_array_elements(pPositions) LOOP
    RAISE NOTICE '[%] %', vIdTarefa, vIndex;
    UPDATE tb_tasks
    SET position = vIndex
    WHERE id_task = vIdTarefa;
    vIndex := vIndex + 1;
  END LOOP;
  vIndex := 0;
  FOR vIdTarefa IN SELECT *
                   FROM json_array_elements(pOldPositions) LOOP
    RAISE NOTICE '[%] %', vIdTarefa, vIndex;
    UPDATE tb_tasks
    SET position = vIndex
    WHERE id_task = vIdTarefa;
    vIndex := vIndex + 1;
  END LOOP;
  RETURN TRUE;
END;
$$;
