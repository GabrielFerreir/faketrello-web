create function changepermissionmember(pidproject integer, pidusertarget integer, permission boolean, piduser integer) returns TABLE(status integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vOldPermission BOOLEAN;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team
            WHERE id_project = pIdProject AND
                  id_user = pIdUserTarget) AND permission = TRUE
  THEN

    SELECT permissions
    INTO vOldPermission
    FROM tb_team
    WHERE id_project = pIdProject AND
          id_user = pIdUserTarget;

    UPDATE tb_team
    SET permissions = NOT permissions
    WHERE id_project = pIdProject AND
          id_user = pIdUserTarget;

    IF vOldPermission = TRUE
    THEN

      INSERT INTO tb_notifications (id_user, id_new_user, type, target_type,id_project)
      VALUES (pIdUser, pIdUserTarget, 9, 6,pIdProject);

      UPDATE tb_team SET notifications = TRUE WHERE id_project = pIdProject AND id_user <> pIdUser;

    ELSE
      
      INSERT INTO tb_notifications (id_user, id_new_user, type, target_type, id_project)
      VALUES (pIdUser, pIdUserTarget, 10, 6,pIdProject);

      UPDATE tb_team SET notifications = TRUE WHERE id_project = pIdProject AND id_user <> pIdUser;
      
    END IF;

    RETURN QUERY
    SELECT 1;
  END IF;
  RETURN QUERY
  SELECT 0;
END;
$$;
