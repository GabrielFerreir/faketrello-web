create function changeteam(idproj integer, idusert integer, permission integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF permission <> 2 AND
     EXISTS(SELECT *
            FROM tb_team
            WHERE idproj = id_project AND id_user = idusert)
  THEN
    DELETE FROM tb_team WHERE idproj = id_project AND id_user = idusert;
    RETURN TRUE ;
  END IF;
  RETURN FALSE ;
END;
$$;
