create function changeteam(idproj integer, idusert integer, permission integer, idprojalvo integer, iduseralvo integer) returns TABLE(statuscode integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vStatus INTEGER;
BEGIN
  IF permission <> 2
  THEN
    IF EXISTS(SELECT *
              FROM tb_team
              WHERE idproj = id_project AND id_user = idusert)
       AND EXISTS(SELECT *
                  FROM tb_team
                  WHERE idprojalvo = id_project AND
                        iduseralvo = id_user)
                  THEN
                  DELETE FROM tb_team
                  WHERE idprojalvo = id_project AND
                        id_user = iduseralvo RETURNING 200 INTO
                  vStatus;
    RETURN QUERY
    SELECT vStatus;
  ELSE
    RETURN QUERY
    SELECT 404;
  END IF;
  ELSE
  RETURN QUERY
SELECT 401;
END IF;
END;
$$;
