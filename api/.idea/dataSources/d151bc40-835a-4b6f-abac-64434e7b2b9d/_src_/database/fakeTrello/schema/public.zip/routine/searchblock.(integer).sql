create function searchblock(projectowner integer) returns TABLE(idblock integer, nameblock character varying, tasks json)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdBlocks INTEGER [];
BEGIN


  vIdBlocks := ARRAY(SELECT id_blocks
                     FROM tb_blocks
                     WHERE project_owner = projectOwner);

  IF vIdBlocks IS NOT NULL
  THEN
    RETURN QUERY
    SELECT
      tb.id_blocks,
      tb.name_blocks,
      (SELECT COALESCE(json_agg(TasksJson), '[]')
       FROM (SELECT
               tt.id_task,
               tt.name_task,
               tt.final_date,
               tt.position,
               (SELECT count(id_attachment)
                FROM tb_attachment ta
                WHERE tt.id_task = ta.id_task) AS attachments,
               (SELECT count(id_comment)
                FROM tb_comments tc
                WHERE tt.id_task = tc.id_task) AS comments,
               (SELECT coalesce(json_agg(teamTask), '[]')
                FROM (SELECT
                        tb_team_tasks.id_user,
                        tb_team_tasks.id_team_task,
                        tb_login.name,
                        tb_login.profile_img,
                        tb_login.email
                      FROM tb_team_tasks
                        INNER JOIN tb_login ON tb_team_tasks.id_user = tb_login.id_user
                      WHERE id_task = tt.id_task) AS teamTask) as teamTask
             FROM tb_tasks tt
             WHERE tt.id_block = tb.id_blocks
             ORDER BY position ASC) AS TasksJson
      ) tasks
    FROM tb_blocks tb
    WHERE tb.id_blocks = ANY (vIdBlocks);
  END IF;
END;
$$;
