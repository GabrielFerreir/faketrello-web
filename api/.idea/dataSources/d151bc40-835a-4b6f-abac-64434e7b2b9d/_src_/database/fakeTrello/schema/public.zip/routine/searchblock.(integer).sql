create function searchblock(projectowner integer) returns TABLE(idblock integer, nameblock character varying, tasks json)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdBlocks INTEGER [];
BEGIN


  vIdBlocks := ARRAY(SELECT id_blocks
                     FROM tb_blocks
                     WHERE project_owner = projectOwner);

  IF vIdBlocks IS NOT NULL
  THEN
    RETURN QUERY
    SELECT
      tb.id_blocks,
      tb.name_blocks,
      (SELECT COALESCE(json_agg(TasksJson), '[]')
       FROM (SELECT
               tt.id_task,
               tt.name_task,
               tt.final_date
             FROM tb_tasks tt
             WHERE tt.id_block = tb.id_blocks) AS TasksJson
      ) tasks
    FROM tb_blocks tb
    WHERE tb.id_blocks = ANY (vIdBlocks);
  END IF;
END;
$$;
