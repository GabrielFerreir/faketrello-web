create function searchblock(projectowner integer) returns TABLE(nameproject character varying, nameblock character varying, tasks json)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdBlocks     INTEGER [];
  vName_project VARCHAR(50);
BEGIN
  SELECT name_project
  INTO vName_project
  FROM tb_projects
  WHERE id_project = projectOwner;

  vIdBlocks := ARRAY(SELECT id_blocks
                     FROM tb_blocks
                     WHERE project_owner = projectOwner);

  IF vIdBlocks IS NOT NULL
  THEN
    RETURN QUERY
    SELECT
      vName_project,
      name_blocks,
      (SELECT COALESCE(json_agg(TasksJson), '[]')
       FROM (SELECT
               id_task,
               name_task,
               final_date
             FROM tb_tasks WHERE id_block = ANY (vIdBlocks)) AS TasksJson
      ) tasks
    FROM tb_blocks
    WHERE id_blocks = ANY (vIdBlocks);
  END IF;
END;
$$;
