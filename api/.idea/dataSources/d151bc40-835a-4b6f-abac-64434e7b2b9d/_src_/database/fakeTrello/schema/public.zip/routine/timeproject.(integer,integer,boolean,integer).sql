create function timeproject(pidproject integer, piduser integer, permission boolean, pidadmin integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF pIdAdmin <> 0 AND EXISTS(SELECT *
                              FROM tb_team
                              WHERE id_user = pIdAdmin AND id_project = pIdProject)
  THEN
    INSERT
    INTO tb_team (id_project, id_user, permissions) VALUES (pIdProject, pIdUser, permission);
    RETURN TRUE;

  ELSEIF pIdAdmin = 0
    THEN
      INSERT
      INTO tb_team (id_project, id_user, permissions) VALUES (pIdProject, pIdUser, permission);
      RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
