create function timeproject(pidproject integer, piduser integer, permission boolean, pidadmin integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_team
            WHERE id_user = pIdAdmin AND id_project = pIdProject AND permissions = TRUE)
  THEN
    INSERT
    INTO tb_team (id_project, id_user, permissions) VALUES (pIdProject, pIdUser, permission);

    INSERT INTO tb_notifications (id_user, type, id_new_user, target_type, id_project)
    VALUES (pIdAdmin, 7, pIdUser, 6, pIdProject);

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
