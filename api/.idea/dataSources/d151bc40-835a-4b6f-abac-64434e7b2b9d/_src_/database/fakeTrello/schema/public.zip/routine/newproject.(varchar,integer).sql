create function newproject(nameproject character varying, iddono integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT
              l.id_user
            FROM tb_login l
            WHERE l.id_user = idDono)
  THEN
      INSERT INTO tb_projects(name_project,id_user_owner) VALUES($1,$2);
    RETURN TRUE ;
  END IF;
  RETURN FALSE ;
END;
$$;
