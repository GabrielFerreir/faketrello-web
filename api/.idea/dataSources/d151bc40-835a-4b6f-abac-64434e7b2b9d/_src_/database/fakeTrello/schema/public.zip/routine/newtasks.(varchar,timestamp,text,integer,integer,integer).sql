create function newtasks(nametask character varying, date timestamp without time zone, descrip text, idblock integer, pposition integer, piduser integer) returns TABLE(idtask integer, nametaskr character varying, dater timestamp without time zone, rdescription text, idblockowner integer, rposition integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask     INTEGER;
  vNameTask   VARCHAR(100);
  vDate       TIMESTAMP;
  vDescript   TEXT;
  vBlockOwner INTEGER;
  vPosition   INTEGER;

BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = idblock)
  THEN
    INSERT INTO tb_tasks (name_task, final_date, description, id_block, position)
    VALUES (nametask, date, descrip, idblock, pPosition)
    RETURNING id_task, name_task, final_date, description, id_block, position
      INTO vIdTask, vNameTask, vDate, vDescript, vBlockOwner, vPosition;

    INSERT INTO tb_notifications (id_user, id_block, id_project, id_task, type, new_name, target_type)
    VALUES (pIdUser, idblock, (SELECT project_owner
                               FROM tb_blocks
                               WHERE id_blocks = idblock), vIdTask, 1, vNameTask, 2);

    RETURN QUERY
    SELECT
      vIdTask,
      vNameTask,
      vDate,
      vDescript,
      vBlockOwner,
      vPosition;
  END IF;
END;
$$;
