create function timeproject(pidproject integer, piduser integer, permission boolean) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO tb_team (id_project, id_user, permissions) VALUES (pIdProject, pIdUser, permission);
  RETURN TRUE;
END;
$$;
