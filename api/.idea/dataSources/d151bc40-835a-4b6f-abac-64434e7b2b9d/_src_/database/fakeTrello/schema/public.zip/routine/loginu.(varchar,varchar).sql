create function loginu(emaild character varying, passw character varying) returns TABLE(id integer, email character varying, password character varying, username character varying, statusemail boolean, senhacorreta boolean)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    tb_login.id_user,
    tb_login.email,
    tb_login.username,
    tb_login.password,
    tb_login."authEmail",
    (tb_login.password = $2)
  FROM tb_login
  WHERE tb_login.email ILIKE $1 OR tb_login.username ILIKE $1;
END
$$;
