create function changepass(usern character varying, oldpass character varying, newpass character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT
              username,
              password
            FROM tb_login
            WHERE (username ILIKE $1 OR email ILIKE $1) AND password = $2)
  THEN
    UPDATE tb_login
    SET password = $3
    WHERE username ILIKE $1 OR email ILIKE $1;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
