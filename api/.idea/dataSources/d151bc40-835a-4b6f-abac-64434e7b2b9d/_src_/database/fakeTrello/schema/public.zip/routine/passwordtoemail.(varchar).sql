create function passwordtoemail(usern character varying) returns TABLE(passwordr character varying, nameuser character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT
              l.username,
              l.email,
              l.password
            FROM tb_login l
            WHERE l.username ILIKE usern OR l.email ILIKE usern)
  THEN
    RETURN QUERY
    SELECT
      l.password,
      l.name
    FROM tb_login l
    WHERE l.username ILIKE usern OR l.email ILIKE usern;
  END IF;
END;
$$;
