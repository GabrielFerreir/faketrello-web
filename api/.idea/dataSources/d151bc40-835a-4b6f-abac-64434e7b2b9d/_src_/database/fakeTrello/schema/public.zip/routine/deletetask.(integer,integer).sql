create function deletetask(pidtask integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vNameTask VARCHAR(100);
  vIdBlock  INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    DELETE FROM tb_notifications
    WHERE id_task = pIdTask;
    
    DELETE FROM tb_comments
    WHERE id_task = pIdTask;

    DELETE FROM tb_attachment
    WHERE id_task = pIdTask;

    DELETE FROM tb_checklist_tasks
    WHERE id_task = pIdTask;

    DELETE FROM tb_team_tasks
    WHERE id_task = pIdTask;

    SELECT
      name_task,
      id_block
    INTO vNameTask, vIdBlock
    FROM tb_tasks
    WHERE id_task = pIdTask;

    DELETE FROM tb_tasks
    WHERE id_task = pIdTask;

    INSERT INTO tb_notifications (id_user, type, old_name, id_block, id_project)
    VALUES (pIdUser, 3, vNameTask, vIdBlock, (SELECT project_owner
                                              FROM tb_blocks
                                              WHERE vIdBlock = id_blocks));

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
