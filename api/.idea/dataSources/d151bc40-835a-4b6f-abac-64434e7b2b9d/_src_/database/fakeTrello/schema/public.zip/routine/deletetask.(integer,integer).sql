create function deletetask(pidtask integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vNameTask  VARCHAR(100);
  vIdBlock   INTEGER;
  vIdProject INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    DELETE FROM tb_notifications
    WHERE id_task = pIdTask;

    DELETE FROM tb_comments
    WHERE id_task = pIdTask;

    DELETE FROM tb_attachment
    WHERE id_task = pIdTask;

    DELETE FROM tb_checklist_tasks
    WHERE id_task = pIdTask;

    DELETE FROM tb_team_tasks
    WHERE id_task = pIdTask;

    SELECT
      tt.name_task,
      tt.id_block,
      (SELECT project_owner
       FROM tb_blocks tb
       WHERE tt.id_block = tb.id_blocks)
    INTO vNameTask, vIdBlock, vIdProject
    FROM tb_tasks tt
    WHERE id_task = pIdTask;

    DELETE FROM tb_tasks
    WHERE id_task = pIdTask;

    INSERT INTO tb_notifications (id_user, type, old_name, id_block, id_project, target_type)
    VALUES (pIdUser, 3, vNameTask, vIdBlock, vIdProject, 2);

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
