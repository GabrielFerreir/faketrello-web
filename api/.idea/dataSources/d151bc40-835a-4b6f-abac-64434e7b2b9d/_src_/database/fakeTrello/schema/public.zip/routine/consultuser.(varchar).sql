create function consultuser(usern character varying) returns TABLE(id_usuario integer, email character varying, username character varying, password character varying, img character varying, name character varying, statusauth boolean)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    tb_login.id_user,
    tb_login.email,
    tb_login.username,
    tb_login.password,
    tb_login.profile_img,
    tb_login.name,
    tb_login."authEmail"
  FROM tb_login
  WHERE tb_login.username ILIKE $1 OR tb_login.email ILIKE $1;
END
$$;
