create function deleteblock(nameblock character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE nameBlock ILIKE name_blocks)
  THEN
    DELETE FROM tb_blocks
    WHERE name_blocks ILIKE nameBlock;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
