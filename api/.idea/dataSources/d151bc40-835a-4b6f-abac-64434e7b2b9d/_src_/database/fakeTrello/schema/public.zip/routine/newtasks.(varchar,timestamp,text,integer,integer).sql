create function newtasks(nametask character varying, date timestamp without time zone, descrip text, idblock integer, pposition integer) returns TABLE(idtask integer, nametaskr character varying, dater timestamp without time zone, rdescription text, idblockowner integer, rposition integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask     INTEGER;
  vNameTask   VARCHAR(20);
  vDate       TIMESTAMP;
  vDescript   TEXT;
  vBlockOwner INTEGER;
  vPosition   INTEGER;

BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = idblock)
  THEN
    INSERT INTO tb_tasks (name_task, final_date, description, id_block, position)
    VALUES (nametask, date, descrip, idblock, pPosition)
    RETURNING id_task, name_task, final_date, description, id_block, position
      INTO vIdTask, vNameTask, vDate, vDescript, vBlockOwner, vPosition;
    RETURN QUERY
    SELECT
      vIdTask,
      vNameTask,
      vDate,
      vDescript,
      vBlockOwner,
      vPosition;
  END IF;
END;
$$;
