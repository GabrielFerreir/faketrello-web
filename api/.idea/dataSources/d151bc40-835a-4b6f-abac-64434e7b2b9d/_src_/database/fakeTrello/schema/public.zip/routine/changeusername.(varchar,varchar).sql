create function changeusername(pnewusername character varying, poldusername character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN

  IF NOT EXISTS(SELECT username
                FROM tb_login
                WHERE username ILIKE pNewUsername)
  THEN
    UPDATE tb_login
    SET username = pNewUsername
    WHERE username = pOldUsername;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END
$$;
