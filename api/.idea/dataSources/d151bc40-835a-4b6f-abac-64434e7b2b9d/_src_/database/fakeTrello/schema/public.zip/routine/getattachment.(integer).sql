create function getattachment(pidtask integer) returns TABLE(filename character varying, size integer, path character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    RETURN QUERY
    SELECT file_name,size,path
    FROM tb_attachment
    WHERE id_task = pIdTask;
  END IF;
END;
$$;
