create function removepathattachment(pidtask integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    UPDATE tb_tasks
    SET attachment = NULL
    WHERE id_task = pIdTask;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
