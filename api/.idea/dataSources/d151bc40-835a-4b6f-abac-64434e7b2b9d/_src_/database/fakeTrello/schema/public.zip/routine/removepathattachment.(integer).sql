create function removepathattachment(pidtask integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    DELETE FROM tb_attachment
    WHERE id_task = pIdTask;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
