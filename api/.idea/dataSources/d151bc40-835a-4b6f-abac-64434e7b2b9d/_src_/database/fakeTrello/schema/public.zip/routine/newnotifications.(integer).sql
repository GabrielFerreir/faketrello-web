create function newnotifications(piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vNotifications BOOLEAN [];
  newNotifications BOOLEAN;
BEGIN

  vNotifications := ARRAY(SELECT notifications
                          FROM tb_team
                          WHERE id_user = pIdUser);

  IF TRUE = ANY (vNotifications) THEN
    newNotifications = TRUE;
    ELSE
    newNotifications = FALSE;
  END IF;
  RETURN newNotifications;
END;
$$;
