create function movetask(pidtask integer, pidblock integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vOldBlock INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask) AND EXISTS(SELECT *
                                                FROM tb_blocks
                                                WHERE id_blocks = pIdBlock)
  THEN
    SELECT id_block
    INTO vOldBlock
    FROM tb_tasks
    WHERE id_task = pIdTask;

    UPDATE tb_tasks
    SET id_block = pIdBlock
    WHERE id_task = pIdTask;

    INSERT INTO tb_notifications (id_user, id_block, id_block_final, id_task, type, id_project)
    VALUES (pIdUser, vOldBlock, pIdBlock, pIdTask, 4, (SELECT project_owner
                                                       FROM tb_blocks
                                                       WHERE id_blocks = vOldBlock));
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
