create function insertteamnewproject(pteam json) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO tb_team (id_project, id_user, permissions)
    SELECT
      idProject,
      idUser,
      permission
    FROM json_to_recordset(pTeam)
      AS x(
         idProject INTEGER,
         idUser INTEGER,
         permission BOOLEAN
         )
  RETURNING TRUE;
END;
$$;
