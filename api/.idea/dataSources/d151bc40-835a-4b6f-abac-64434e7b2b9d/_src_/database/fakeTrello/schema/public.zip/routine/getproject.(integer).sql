create function getproject(usern integer) returns TABLE(namep character varying, descrip text, img character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_user_owner = usern)
  THEN
    RETURN QUERY
    SELECT
      name_project,
      description,
      img_project
    FROM tb_projects
    WHERE id_user_owner = usern;
  END IF;
END;
$$;
