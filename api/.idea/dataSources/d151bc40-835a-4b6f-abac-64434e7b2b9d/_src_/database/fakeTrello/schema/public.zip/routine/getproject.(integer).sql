create function getproject(usern integer) returns TABLE(idproject integer, namep character varying, descrip text, img character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_user_owner = usern)
  THEN
    RETURN QUERY
    SELECT
      id_project,
      name_project,
      description,
      img_project
    FROM tb_projects
    WHERE id_user_owner = usern
      ORDER BY id_project ASC ;
  END IF;
END;
$$;
