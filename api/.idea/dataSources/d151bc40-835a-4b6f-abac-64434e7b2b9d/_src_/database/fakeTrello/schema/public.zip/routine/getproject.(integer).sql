create function getproject(usern integer) returns TABLE(id_project integer, namep character varying, descrip text, img character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    tb_projects.id_project,
    name_project,
    description,
    img_project
  FROM tb_projects
  WHERE  tb_projects.id_project IN (SELECT tb_team.id_project
                       FROM tb_team
                       WHERE usern = id_user);
END;
$$;
