create function getproject(usern integer) returns TABLE(id_project integer, namep character varying, descrip text, img character varying, permission boolean)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    tp.id_project,
    name_project,
    description,
    img_project,
    (SELECT permissions
     FROM tb_team tt
     WHERE id_user = usern AND tt.id_project = tp.id_project)
  FROM tb_projects tp
  WHERE tp.id_project IN (SELECT tb_team.id_project
                          FROM tb_team
                          WHERE usern = id_user) AND active <> FALSE;
END;
$$;
