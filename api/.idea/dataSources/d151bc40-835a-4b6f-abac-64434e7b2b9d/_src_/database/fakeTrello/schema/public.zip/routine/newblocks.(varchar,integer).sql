create function newblocks(nameq character varying, idproj integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT * FROM tb_projects WHERE id_project = idproj) THEN 
    INSERT INTO tb_blocks(name_blocks, project_owner) VALUES(nameq, idproj);
    RETURN TRUE ;
  END IF;
  RETURN FALSE ;
END;
$$;
