create function getpathattachment(pidattachment integer) returns TABLE(path character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT l.path
            FROM tb_attachment l
            WHERE id_attachment = pIdAttachment)
  THEN
    RETURN QUERY
    SELECT l.path
    FROM tb_attachment l
    WHERE id_attachment = pIdAttachment;
  END IF;
END;
$$;
