create function getpathattachment(pidtask integer) returns TABLE(path character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    RETURN QUERY
    SELECT attachment
    FROM tb_tasks
    WHERE id_task = pIdTask;
  END IF;
END;
$$;
