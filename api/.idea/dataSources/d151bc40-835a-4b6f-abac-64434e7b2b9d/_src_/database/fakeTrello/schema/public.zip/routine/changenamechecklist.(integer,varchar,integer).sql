create function changenamechecklist(pidchecklist integer, pname character varying, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vOldName   VARCHAR(100);
  vIdTask    INTEGER;
  vIdBlock   INTEGER;
  vIdProject INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_checklist_tasks
            WHERE id_checklist = pIdChecklist)
  THEN

    SELECT name_checklist
    INTO vOldName
    FROM tb_checklist_tasks
    WHERE id_checklist = pIdChecklist;

    UPDATE tb_checklist_tasks
    SET name_checklist = pName
    WHERE id_checklist = pIdChecklist;

    SELECT
      id_task,
      (SELECT id_block
       FROM tb_tasks
       WHERE tct.id_task = tb_tasks.id_task)
    INTO vIdTask, vIdBlock
    FROM tb_checklist_tasks tct
    WHERE id_checklist = pIdChecklist;

    SELECT project_owner
    INTO vIdProject
    FROM tb_blocks
    WHERE id_blocks = vIdBlock;

    INSERT INTO tb_notifications (id_checklist, type, target_type, id_user, old_name, new_name, id_task, id_block, id_project)
    VALUES (pIdChecklist, 2, 4, pIdUser, vOldName, pName, vIdTask, vIdBlock, vIdProject);

    UPDATE tb_team
    SET notifications = TRUE
    WHERE id_project = vIdProject AND id_user <> pIdUser;

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
