create function changestatuschecklist(pidchecklist integer, piduser integer) returns TABLE(rstatus text)
LANGUAGE plpgsql
AS $$
DECLARE
  vStatus    BOOLEAN;
  vIdTask    INTEGER;
  vIdBlock   INTEGER;
  vIdProject INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_checklist_tasks
            WHERE id_checklist = pIdChecklist)
  THEN

    SELECT checked
    INTO vStatus
    FROM tb_checklist_tasks
    WHERE id_checklist = pIdChecklist;

    UPDATE tb_checklist_tasks
    SET checked = NOT checked
    WHERE id_checklist = pIdChecklist;

    SELECT
      id_task,
      (SELECT id_block
       FROM tb_tasks
       WHERE tct.id_task = tb_tasks.id_task)
    INTO vIdTask, vIdBlock
    FROM tb_checklist_tasks tct
    WHERE id_checklist = pIdChecklist;

    SELECT project_owner
    INTO vIdProject
    FROM tb_blocks
    WHERE id_blocks = vIdBlock;

    IF vStatus = TRUE
    THEN

      INSERT INTO tb_notifications (id_checklist, type, target_type, id_user, id_task, id_block, id_project)
      VALUES (pIdChecklist, 6, 4, pIdUser, vIdTask, vIdBlock, vIdProject);

      UPDATE tb_team
      SET notifications = TRUE
      WHERE id_project = vIdProject AND id_user <> pIdUser;

      RETURN QUERY
      SELECT 'desmarcada' :: TEXT;
      
    ELSE
      
      INSERT INTO tb_notifications (id_checklist, type, target_type, id_user, id_task, id_block, id_project)
      VALUES (pIdChecklist, 5, 4, pIdUser, vIdTask, vIdBlock, vIdProject);

      UPDATE tb_team
      SET notifications = TRUE
      WHERE id_project = vIdProject AND id_user <> pIdUser;

      RETURN QUERY
      SELECT 'marcada' :: TEXT;


    END IF;
  ELSE
    RETURN QUERY
    SELECT 'Erro' :: TEXT;
  END IF;
END;
$$;
