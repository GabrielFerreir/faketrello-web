create function changestatuschecklist(pidchecklist integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_checklist_tasks
            WHERE id_checklist = pIdChecklist)
  THEN
    UPDATE tb_checklist_tasks
    SET checked = NOT checked
    WHERE id_checklist = pIdChecklist;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
