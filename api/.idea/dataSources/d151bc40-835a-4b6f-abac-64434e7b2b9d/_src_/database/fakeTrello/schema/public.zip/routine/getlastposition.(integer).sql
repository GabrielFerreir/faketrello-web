create function getlastposition(pidblock integer) returns TABLE("position" integer)
LANGUAGE plpgsql
AS $$
DECLARE
  reg           tb_tasks%ROWTYPE;
  vLastPosition INTEGER := 0;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = pIdBlock)
  THEN
    RAISE NOTICE '%', vLastPosition;

    FOR reg IN
    SELECT l.position
    FROM tb_tasks l
    LOOP
      RAISE NOTICE 'ANTES %', vLastPosition;


      IF (SELECT l.position
          FROM tb_tasks l
          WHERE l.position > vLastPosition LIMIT 1) IS NOT NULL
      THEN
        SELECT l.position
        INTO vLastPosition
        FROM tb_tasks l
        WHERE l.position > vLastPosition;
      END IF;
      RAISE NOTICE 'DEPOIS %', vLastPosition;
    END LOOP;
  END IF;

  RETURN QUERY
  SELECT vLastPosition;
END;
$$;
