create function getlastposition(pidblock integer) returns TABLE("position" integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vLastPosition INTEGER := -1;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = pIdBlock)
  THEN

    IF (SELECT l.position
        FROM tb_tasks l
        WHERE l.position > vLastPosition AND l.id_block = pIdBlock
        ORDER BY l.position DESC
        LIMIT 1) IS NOT NULL
    THEN

      SELECT l.position
      INTO vLastPosition
      FROM tb_tasks l
      WHERE l.position > vLastPosition AND l.id_block = pIdBlock
      ORDER BY l.position DESC
      LIMIT 1;
    END IF;
    RETURN QUERY
    SELECT (vLastPosition + 1);
  END IF;
END;
$$;
