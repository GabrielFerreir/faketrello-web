create function changenamechecklist(pidchecklist integer, pname character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_checklist_tasks
            WHERE id_checklist = pIdChecklist)
  THEN
    UPDATE tb_checklist_tasks
    SET name_checklist = pName
    WHERE id_checklist = pIdChecklist;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
