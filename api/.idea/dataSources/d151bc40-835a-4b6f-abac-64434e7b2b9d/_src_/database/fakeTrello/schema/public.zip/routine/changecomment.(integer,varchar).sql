create function changecomment(pidcomment integer, pnewcomment character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_comments
            WHERE id_comment = pIdComment)
  THEN
    UPDATE tb_comments
    SET comment = pNewComment
    WHERE id_comment = pIdComment;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
