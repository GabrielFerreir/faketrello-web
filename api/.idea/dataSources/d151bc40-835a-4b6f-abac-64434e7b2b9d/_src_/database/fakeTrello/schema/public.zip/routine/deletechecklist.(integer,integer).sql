create function deletechecklist(pidchecklist integer, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vOldName   VARCHAR(100);
  vIdTask    INTEGER;
  vIdBlock   INTEGER;
  vIdProject INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_checklist_tasks
            WHERE id_checklist = pIdChecklist)
  THEN
    DELETE FROM tb_notifications
    WHERE id_checklist = pIdChecklist;

    SELECT name_checklist
    INTO vOldName
    FROM tb_checklist_tasks
    WHERE id_checklist = pIdChecklist;

    SELECT
      id_task,
      (SELECT tt.id_block
       FROM tb_tasks tt
       WHERE tt.id_task = tct.id_task)
    INTO vIdTask, vIdBlock
    FROM tb_checklist_tasks tct
    WHERE id_checklist = pIdChecklist;

    SELECT project_owner
    INTO vIdProject
    FROM tb_blocks
    WHERE id_blocks = vIdBlock;

    INSERT INTO tb_notifications (id_user, type, target_type, id_task, old_name, id_block, id_project)
    VALUES (pIdUser, 3, 5, vIdTask, vOldName, vIdBlock, vIdProject);

    DELETE FROM tb_checklist_tasks
    WHERE id_checklist = pIdChecklist;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
