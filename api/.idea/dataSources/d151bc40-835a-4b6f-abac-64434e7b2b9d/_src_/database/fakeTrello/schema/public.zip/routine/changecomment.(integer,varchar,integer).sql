create function changecomment(pidcomment integer, pnewcomment character varying, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask    INTEGER;
  vIdBlock   INTEGER;
  vIdProject INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_comments
            WHERE id_comment = pIdComment)
  THEN
    UPDATE tb_comments
    SET comment = pNewComment
    WHERE id_comment = pIdComment;

    SELECT
      tc.id_task,
      (SELECT id_block
       FROM tb_tasks tt
       WHERE tt.id_task = tc.id_task)
    INTO vIdTask, vIdBlock
    FROM tb_comments tc
    WHERE id_comment = pIdComment;

    SELECT project_owner
    INTO vIdProject
    FROM tb_blocks
    WHERE id_blocks = vIdBlock;

    INSERT INTO tb_notifications (id_user, type, target_type, id_comment, id_task, id_block, id_project)
    VALUES (pIdUser, 2, 3, pIdComment, vIdTask, vIdBlock, vIdProject);

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
