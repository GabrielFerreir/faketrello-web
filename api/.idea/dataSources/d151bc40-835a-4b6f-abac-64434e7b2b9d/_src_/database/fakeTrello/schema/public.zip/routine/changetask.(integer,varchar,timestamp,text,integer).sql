create function changetask(pidtask integer, pnametask character varying, pdate timestamp without time zone, pdescription text, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vOldName VARCHAR(100);
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    SELECT name_task
    INTO vOldName
    FROM tb_tasks
    WHERE id_task = pIdTask;

    UPDATE tb_tasks
    SET name_task = pNameTask,
      final_date  = pDate,
      description = pDescription
    WHERE id_task = pIdTask;

    IF vOldName = (SELECT name_task
                   FROM tb_tasks
                   WHERE id_task = pIdTask)
    THEN
      INSERT INTO tb_notifications (id_task, type, id_user, target_type, id_block, id_project)
      VALUES (pIdTask,
              2,
              pIdUser, 2, (SELECT id_block
                           FROM tb_tasks
                           WHERE id_task = pIdTask), (SELECT project_owner
                                                      FROM tb_blocks
                                                      WHERE id_blocks = (SELECT id_block
                                                                         FROM tb_tasks
                                                                         WHERE id_task = pIdTask)));

      UPDATE tb_team
      SET notifications = TRUE
      WHERE id_project = (SELECT project_owner
                          FROM tb_blocks
                          WHERE id_blocks = (SELECT id_block
                                             FROM tb_tasks
                                             WHERE id_task = pIdTask)) AND id_user <> pIdUser;
      
    ELSE
      INSERT INTO tb_notifications (id_task, type, id_user, old_name, new_name, target_type, id_block, id_project)
      VALUES (pIdTask,
              2,
              pIdUser,
              vOldName,
              (SELECT name_task
               FROM tb_tasks
               WHERE tb_tasks.id_task = pIdTask),
              2,
              (SELECT id_block
               FROM tb_tasks
               WHERE id_task = pIdTask),
              (SELECT project_owner
               FROM tb_blocks
               WHERE id_blocks = (SELECT id_block
                                  FROM tb_tasks
                                  WHERE id_task = pIdTask)));

      UPDATE tb_team
      SET notifications = TRUE
      WHERE id_project = (SELECT project_owner
                          FROM tb_blocks
                          WHERE id_blocks = (SELECT id_block
                                             FROM tb_tasks
                                             WHERE id_task = pIdTask)) AND id_user <> pIdUser;
      
    END IF;
    RETURN TRUE;

  END IF;
  RETURN FALSE;
END;
$$;
