create function searchblock(projectowner character varying) returns TABLE(nameblock character varying, nametasks character varying, anexo character varying, datafinal timestamp without time zone)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdBlocks INTEGER [];
  vIdTasks  INTEGER [];
BEGIN
  vIdBlocks := ARRAY(SELECT id_blocks
                     FROM tb_blocks
                     WHERE project_owner = projectOwner);

  IF vIdBlocks IS NOT NULL
  THEN
    vIdTasks := ARRAY(SELECT *
                      FROM tb_tasks
                      WHERE id_block = ANY (vIdBlocks));
  END IF;
  RETURN QUERY
  SELECT
    name_blocks,
    name_task,
    attachment,
    final_date
  FROM tb_blocks
    INNER JOIN tb_tasks ON tb_blocks.id_blocks = tb_tasks.id_block
  WHERE id_blocks = ANY (vIdBlocks) AND id_block = ANY (vIdBlocks);
END;
$$;
