create function searchblock(project_owner character varying) returns TABLE(nameblock character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT id_project
            FROM tb_projects
            WHERE id_project = project_owner)
  THEN
    RETURN QUERY
    SELECT name_blocks
    FROM tb_blocks
    WHERE project_owner = $1;
  END IF;
  RETURN QUERY
  SELECT FALSE;
END;
$$;
