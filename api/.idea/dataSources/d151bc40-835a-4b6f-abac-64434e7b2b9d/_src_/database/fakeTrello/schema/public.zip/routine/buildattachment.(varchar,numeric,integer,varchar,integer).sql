create function buildattachment(pfilename character varying, psize numeric, pidtask integer, ppath character varying, piduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vIdAttachment INTEGER;
  vIdBlock      INTEGER;
  vIdProject    INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    INSERT INTO tb_attachment (file_name, size, id_task, path)
    VALUES (pFileName, pSize, pIdTask, pPath)
    RETURNING id_attachment
      INTO vIdAttachment;

    SELECT
      tt.id_block,
      (SELECT project_owner
       FROM tb_blocks
       WHERE id_blocks = tt.id_block)
    INTO vIdBlock, vIdProject
    FROM tb_tasks tt
    WHERE id_task = pIdTask;

    INSERT INTO tb_notifications (id_attachment, type, target_type, old_name, id_block, id_project, id_task, id_user)
    VALUES (vIdAttachment, 1, 5, pFileName, vIdBlock, vIdProject, pIdTask, pIdUser);

    UPDATE tb_team
    SET notifications = TRUE
    WHERE id_project = vIdProject AND id_user <> pIdUser;

    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
