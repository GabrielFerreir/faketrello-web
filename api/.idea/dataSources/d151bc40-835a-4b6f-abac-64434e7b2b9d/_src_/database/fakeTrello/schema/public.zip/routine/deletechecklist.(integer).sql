create function deletechecklist(pidchecklist integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_checklist_tasks
            WHERE id_checklist = pIdChecklist)
  THEN
    DELETE FROM tb_notifications WHERE id_checklist = pIdChecklist;
    
    DELETE FROM tb_checklist_tasks
    WHERE id_checklist = pIdChecklist;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
