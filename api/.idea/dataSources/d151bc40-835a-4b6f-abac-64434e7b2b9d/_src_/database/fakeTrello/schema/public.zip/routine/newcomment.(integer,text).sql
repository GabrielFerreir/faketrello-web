create function newcomment(pidtask integer, pcomment text) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    INSERT INTO tb_comments (id_task, comment) VALUES (pIdTask, pComment);
    RETURN TRUE ;
  END IF;
  RETURN FALSE ;
END;
$$;
