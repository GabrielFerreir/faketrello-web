create function newcomment(pidtask integer, pcomment text) returns TABLE(idcomment integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdComment INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    INSERT INTO tb_comments (id_task, comment) VALUES (pIdTask, pComment)
    RETURNING id_comment
      INTO vIdComment;
    RETURN QUERY
    SELECT vIdComment;
  END IF;
END;
$$;
