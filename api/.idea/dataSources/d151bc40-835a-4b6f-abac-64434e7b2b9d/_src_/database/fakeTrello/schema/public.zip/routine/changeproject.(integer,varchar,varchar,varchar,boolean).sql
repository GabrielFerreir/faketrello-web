create function changeproject(idproj integer, namep character varying, descrip character varying, imgp character varying, permission boolean) returns TABLE(idprojectr integer)
LANGUAGE plpgsql
AS $$
DECLARE
  idproject INTEGER;
BEGIN
  IF permission <> FALSE AND
     EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = idproj)
  THEN
    UPDATE tb_projects
    SET
      name_project = namep,
      description  = descrip,
      img_project  = imgp,
      active = TRUE 
    WHERE id_project = idproj
    RETURNING id_project
      INTO idproject;
    RETURN QUERY
    SELECT idproject;
  END IF;
END;
$$;
