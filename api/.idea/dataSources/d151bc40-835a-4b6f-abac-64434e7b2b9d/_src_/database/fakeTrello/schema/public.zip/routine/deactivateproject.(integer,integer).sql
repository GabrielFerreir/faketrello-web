create function deactivateproject(idproject integer, iduser integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = $1 AND active = TRUE)
     AND ((SELECT permissions
          FROM tb_team
          WHERE id_user = idUser AND id_project = idproject) = TRUE)
  THEN
    UPDATE tb_projects
    SET active = FALSE
    WHERE id_project = $1;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
