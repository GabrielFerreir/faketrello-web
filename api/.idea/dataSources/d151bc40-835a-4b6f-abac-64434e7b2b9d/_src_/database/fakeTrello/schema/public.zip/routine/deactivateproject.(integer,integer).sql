create function deactivateproject(idproject integer, iduser integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  vPermission BOOLEAN;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = idproject AND active = TRUE)
  THEN
    SELECT permissions
    INTO vPermission
    FROM tb_team
    WHERE id_project = idproject AND id_user = idUser;

    IF vPermission = TRUE
    THEN
      UPDATE tb_projects
      SET active = FALSE
      WHERE id_project = idproject;
      RETURN TRUE;
    END IF;
    RETURN FALSE;
  END IF;
  RETURN FALSE;
END;
$$;
