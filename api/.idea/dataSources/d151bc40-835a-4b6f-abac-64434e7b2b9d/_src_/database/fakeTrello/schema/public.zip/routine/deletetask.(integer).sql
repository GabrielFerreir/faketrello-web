create function deletetask(pidtask integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_tasks
            WHERE id_task = pIdTask)
  THEN
    DELETE FROM tb_comments
    WHERE id_task = pIdTask;

    DELETE FROM tb_checklist_tasks
    WHERE id_task = pIdTask;

    DELETE FROM tb_team_tasks
    WHERE id_task = pIdTask;

    DELETE FROM tb_tasks
    WHERE id_task = pIdTask;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
