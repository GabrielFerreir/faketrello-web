create function verify_imgproject(imgpath character varying, usern integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT
              img_project,
              name_project
            FROM tb_projects
            WHERE tb_projects.id_project = usern)
  THEN
    UPDATE tb_projects
    SET img_project = imgPath
    WHERE tb_projects.id_project = usern;
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
END;
$$;
