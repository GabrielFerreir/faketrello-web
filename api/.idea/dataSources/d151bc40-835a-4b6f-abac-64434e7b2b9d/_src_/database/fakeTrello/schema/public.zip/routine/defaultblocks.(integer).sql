create function defaultblocks(pidproject integer) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT id_project
            FROM tb_projects
            WHERE id_project = pIdProject)
  THEN
    INSERT INTO tb_blocks (name_blocks, project_owner)
    VALUES ('A fazer', pIdProject),
      ('Fazendo', pIdProject),
      ('Concluído', pIdProject);
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END;
$$;
