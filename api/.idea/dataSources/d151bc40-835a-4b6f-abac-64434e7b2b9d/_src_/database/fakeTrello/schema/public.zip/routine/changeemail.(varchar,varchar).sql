create function changeemail(pnewemail character varying, poldemail character varying) returns boolean
LANGUAGE plpgsql
AS $$
BEGIN

  IF NOT EXISTS(SELECT email
                FROM tb_login
                WHERE email ILIKE pNewEmail)
  THEN
    UPDATE tb_login
    SET email = pNewEmail
    WHERE email = pOldEmail;
    RETURN TRUE;
  END IF;
  RETURN FALSE;
END
$$;
