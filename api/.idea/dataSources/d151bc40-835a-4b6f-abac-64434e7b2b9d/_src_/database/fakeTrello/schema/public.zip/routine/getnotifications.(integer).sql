create function getnotifications(piduser integer) returns TABLE(idtask integer, nametask character varying, idblock integer, nameblock character varying, idproject integer, nameproject character varying, iduser integer, nameuser character varying, imguser character varying, idattachment integer, idcomment integer, idchecklist integer, type integer, idblockfinal integer, nameblockfinal character varying, oldname character varying, newname character varying, targettype integer, idnewuser integer, namenewuser character varying, imgnewuser character varying, date timestamp without time zone)
LANGUAGE plpgsql
AS $$
DECLARE
  vArrayProjects INTEGER [];
BEGIN
  vArrayProjects := ARRAY(SELECT id_project
                          FROM tb_team
                          WHERE id_user = pIdUser);
  RETURN QUERY
  SELECT
    tn.id_task,
    (SELECT name_task
     FROM tb_tasks
     WHERE tn.id_task = tb_tasks.id_task),
    tn.id_block,
    (SELECT name_blocks
     FROM tb_blocks
     WHERE tn.id_block = tb_blocks.id_blocks),
    tn.id_project,
    (SELECT name_project
     FROM tb_projects
     WHERE tn.id_project = tb_projects.id_project),
    tn.id_user,
    (SELECT name
     FROM tb_login
     WHERE tn.id_user = tb_login.id_user),
    (SELECT profile_img
     FROM tb_login
     WHERE tn.id_user = tb_login.id_user),
    tn.id_attachment,
    tn.id_comment,
    tn.id_checklist,
    tn.type,
    tn.id_block_final,
    (SELECT name_blocks
     FROM tb_blocks
     WHERE id_blocks = tn.id_block_final),
    tn.old_name,
    tn.new_name,
    tn.target_type,
    tn.id_new_user,
    (SELECT name
     FROM tb_login
     WHERE tn.id_new_user = tb_login.id_user),
    (SELECT profile_img
     FROM tb_login
     WHERE tn.id_new_user = tb_login.id_user),
    tn.date
  FROM tb_notifications tn
  WHERE (id_project = ANY (vArrayProjects)) AND ((SELECT active
                                                  FROM tb_projects
                                                  WHERE tn.id_project = tb_projects.id_project) = TRUE)
  ORDER BY date DESC
  LIMIT 5;
END;
$$;
