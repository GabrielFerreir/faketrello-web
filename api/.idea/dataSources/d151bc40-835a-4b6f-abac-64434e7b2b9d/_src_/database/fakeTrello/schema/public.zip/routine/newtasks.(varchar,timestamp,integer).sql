create function newtasks(nametask character varying, date timestamp without time zone, idblock integer) returns TABLE(idtask integer, nametaskr character varying, dater timestamp without time zone, idblockowner integer)
LANGUAGE plpgsql
AS $$
DECLARE
  vIdTask     INTEGER;
  vNameTask   VARCHAR(20);
  vDate       TIMESTAMP;
  vBlockOwner INTEGER;
BEGIN
  IF EXISTS(SELECT *
            FROM tb_blocks
            WHERE id_blocks = idblock)
  THEN
    INSERT INTO tb_tasks (name_task, final_date, id_block) VALUES (nametask, date, idblock)
    RETURNING id_task, name_task, final_date, id_block
      INTO vIdTask, vNameTask, vDate, vBlockOwner;
    RETURN QUERY
    SELECT
      vIdTask,
      vNameTask,
      vDate,
      vBlockOwner;
  END IF;
END;
$$;
