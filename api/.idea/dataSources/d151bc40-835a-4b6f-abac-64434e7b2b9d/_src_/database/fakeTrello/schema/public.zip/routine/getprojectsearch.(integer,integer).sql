create function getprojectsearch(idpro integer, iduser integer) returns TABLE(namep character varying, descrip text, img character varying, loggeduserpermission boolean, team json)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT id_project
            FROM tb_team
            WHERE id_project = $1 AND id_user = $2)
  THEN
    RETURN QUERY
    SELECT
      name_project,
      description,
      img_project,
      (SELECT permissions
       FROM tb_team
       WHERE id_project = idpro AND id_user = iduser),
      (
        SELECT COALESCE(json_agg(teamJson), '[]')
        FROM (SELECT
                tb_team.id_user,
                name,
                profile_img,
                email,
                username,
                permissions
              FROM tb_team
                INNER JOIN tb_login ON tb_login.id_user = tb_team.id_user
              WHERE id_project = idpro
              ORDER BY permissions DESC) AS teamJson
      ) teams
    FROM tb_projects

    WHERE tb_projects.id_project = idpro;
  END IF;
END;
$$;
