create function getprojectsearch(idpro integer, iduser integer) returns TABLE(idowner integer, namep character varying, descrip text, img character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS(SELECT *
            FROM tb_projects
            WHERE id_project = $1 AND id_user_owner = $2)
  THEN
    RETURN QUERY
    SELECT
      id_user_owner,
      name_project,
      description,
      img_project
    FROM tb_projects
    WHERE id_project = $1;
  END IF;
END;
$$;
