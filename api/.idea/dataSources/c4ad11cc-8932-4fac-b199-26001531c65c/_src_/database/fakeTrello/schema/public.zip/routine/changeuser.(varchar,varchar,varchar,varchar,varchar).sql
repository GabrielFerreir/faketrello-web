create function changeuser(pass character varying, usern character varying, usertoken character varying, emailp character varying, nomep character varying) returns TABLE(emaild character varying, namep character varying, usernamer character varying, passwordr character varying, imageuser character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  IF userToken <> $2
  THEN
    IF EXISTS(SELECT *
              FROM tb_login l
              WHERE l.username = $3 OR l.email = $3)
       AND NOT EXISTS(SELECT
                        l.username,
                        l.email
                      FROM tb_login l
                      WHERE l.username = $2 OR l.email = $4)
    THEN

      UPDATE tb_login l
      SET username = $2,
        password   = $1,
        email      = $4,
        name       = $5
      WHERE l.username = $3 OR l.email = $4;

      RETURN QUERY
      SELECT
        $4,
        $5,
        $2,
        $1,
        tb_login.profile_img
      FROM tb_login;
    END IF;
  ELSE
    UPDATE tb_login l
    SET
      password = $1,
      email    = $4,
      name     = $5
    WHERE l.username = $3 OR l.email = $4;

    RETURN QUERY
    SELECT
      $4,
      $5,
      $2,
      $1,
      tb_login.profile_img
    FROM tb_login;
  END IF;
END
$$;
