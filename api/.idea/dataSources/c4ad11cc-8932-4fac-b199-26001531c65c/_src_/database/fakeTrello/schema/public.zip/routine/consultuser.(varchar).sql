create function consultuser(usern character varying) returns TABLE(email character varying, username character varying, password character varying, img character varying, name character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    tb_login.email,
    tb_login.username,
    tb_login.password,
    tb_login.profile_img,
    tb_login.name
  FROM tb_login WHERE tb_login.username ILIKE $1 OR tb_login.email ILIKE $1;
END
$$;
